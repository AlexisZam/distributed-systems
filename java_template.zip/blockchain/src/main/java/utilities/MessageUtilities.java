package utilities;

import beans.Block;
import beans.Message;
import beans.MessageType;
import com.sun.security.ntlm.Client;
import entities.Blockchain;
import entities.NodeMiner;
import entities.Transaction;
import threads.ClientThread;

import javax.xml.soap.Node;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Helper Utility class that defines a different functionality for each incoming message
 */
public class MessageUtilities {


}
