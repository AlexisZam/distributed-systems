package beans;

import java.io.Serializable;

/*
 * Todo : Message Class Contains anything that will be sent above the network
 */
public class Message implements Serializable {


}
